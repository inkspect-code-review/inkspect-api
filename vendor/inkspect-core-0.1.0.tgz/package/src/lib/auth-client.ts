"use client";

import { createAuthClient } from "better-auth/react";
import { magicLinkClient, organizationClient, twoFactorClient } from "better-auth/client/plugins";

import { passkeyClient } from "@better-auth/passkey/client";

export const authClient = createAuthClient({ plugins: [magicLinkClient(), organizationClient(), twoFactorClient(), passkeyClient()] });
